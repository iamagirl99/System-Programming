/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_488(unsigned *p)
{
    *p = 3281031256U;
}

unsigned getval_169()
{
    return 2430090543U;
}

void setval_452(unsigned *p)
{
    *p = 3284633928U;
}

void setval_121(unsigned *p)
{
    *p = 3251079496U;
}

unsigned addval_166(unsigned x)
{
    return x + 3347662974U;
}

unsigned getval_414()
{
    return 2428995656U;
}

unsigned getval_137()
{
    return 2680379587U;
}

unsigned getval_347()
{
    return 1332724312U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_461(unsigned x)
{
    return x + 3353381192U;
}

unsigned addval_380(unsigned x)
{
    return x + 3524840073U;
}

unsigned addval_294(unsigned x)
{
    return x + 3246503489U;
}

unsigned addval_348(unsigned x)
{
    return x + 3286272329U;
}

unsigned getval_228()
{
    return 3221799177U;
}

void setval_231(unsigned *p)
{
    *p = 3534018185U;
}

void setval_113(unsigned *p)
{
    *p = 3378566793U;
}

unsigned getval_109()
{
    return 3380136585U;
}

unsigned addval_401(unsigned x)
{
    return x + 3674789517U;
}

void setval_473(unsigned *p)
{
    *p = 3373848201U;
}

unsigned getval_220()
{
    return 3353381192U;
}

unsigned getval_300()
{
    return 3374367113U;
}

unsigned getval_292()
{
    return 3523789197U;
}

unsigned addval_366(unsigned x)
{
    return x + 3767093411U;
}

unsigned getval_407()
{
    return 2462746902U;
}

void setval_225(unsigned *p)
{
    *p = 3523794569U;
}

void setval_351(unsigned *p)
{
    *p = 3284244957U;
}

unsigned addval_272(unsigned x)
{
    return x + 3353381192U;
}

void setval_209(unsigned *p)
{
    *p = 3523791497U;
}

unsigned addval_133(unsigned x)
{
    return x + 3372799641U;
}

void setval_103(unsigned *p)
{
    *p = 2430634313U;
}

unsigned addval_464(unsigned x)
{
    return x + 3525364365U;
}

unsigned getval_279()
{
    return 2430634312U;
}

unsigned getval_336()
{
    return 3375421065U;
}

unsigned addval_115(unsigned x)
{
    return x + 3269495112U;
}

void setval_128(unsigned *p)
{
    *p = 3374369289U;
}

void setval_354(unsigned *p)
{
    *p = 3372796553U;
}

void setval_477(unsigned *p)
{
    *p = 3677935241U;
}

unsigned getval_437()
{
    return 3376988553U;
}

unsigned addval_143(unsigned x)
{
    return x + 2445969746U;
}

unsigned getval_362()
{
    return 2428602677U;
}

unsigned addval_375(unsigned x)
{
    return x + 3677929881U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}

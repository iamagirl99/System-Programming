//2019076708

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include "cachelab.h"

const int m = sizeof(long) * 8;
int hit = 0, miss = 0, evict= 0;
int v_flag = 0, h_flag = 0;
int s, b, E, t;
char *trace;


struct line {
    int valid ;
    unsigned tag ;
    struct line *next;
};

struct set {
    int E;
    struct line *line_head;
    struct set *next;
};

struct cache {
    int S;
    struct set *head_set;
};


void init_set(struct set *set, int E){
    set->E = E;
    set->line_head = NULL;
    set->next = NULL;
}


void init_cache(struct cache *cache, int s, int E) {
    cache->S = (1 << s);
    struct set* newset = (struct set*)malloc(sizeof(struct set));
    init_set(newset, E);
    cache->head_set = newset;
    int i;
    for(i = 1; i < cache->S; ++i){
        struct set* temp = (struct set*)malloc(sizeof(struct set));
        init_set(temp, E);
        newset->next = temp;
        newset = temp;
    }
}


int set_size(struct set *set){
    struct line* curline = set->line_head;
    int size = 0;
    while(curline != NULL){
    	++size;
        curline = curline->next;
    }
    return size;
}


void delete_last_line(struct set *set){
    struct line* curline = set->line_head;
    struct line* prev2 = NULL;
    struct line* prevline = NULL;
    while(curline != NULL){
        prev2 = prevline;
        prevline = curline;
        curline = curline->next;
    }
    
    if(prev2 != NULL){
        prev2->next = NULL;
    }
    else{
        set->line_head = NULL;
    }
    if(prevline != NULL){
        free(prevline);
    }
}


void move_line_to_head(struct set *set, struct line *line, struct line *prev){
    if(prev != NULL){
        prev->next = line->next;
        line->next = set->line_head;
        set->line_head = line;
    }
}


void add_line_to_head(struct set *set, struct line *line){
    if(set_size(set) == set->E){
        delete_last_line(set);
        evict++;
        if(v_flag){
            printf(" eviction");
        }
    }
    line->next = set->line_head;
    set->line_head = line;
}


void cache_access(struct cache *cache, unsigned address){

    int tag_bits = address >> (s+b);
    int set_bits = (address << t) >> (t+b);

    struct set *target_set = cache->head_set;
    int i;
    for (i = 0; i < set_bits; i++){
        target_set = target_set->next;
    }

    struct line *line = target_set->line_head;
    struct line *prev = NULL;
    
    
    while (line != NULL){
        if (line->valid && (line->tag == tag_bits)){
            hit++;
            if (v_flag){
                printf(" hit");
            }
            move_line_to_head(target_set, line, prev);
            return;
        }
        prev = line;
        line = line->next;
    }

    miss++;
    if (v_flag){
        printf(" miss");
    }
    
    struct line *newline = (struct line *)malloc(sizeof(struct line));
    newline->valid = 1;
    newline->tag = tag_bits;
    add_line_to_head(target_set,newline);
    
}


void free_all(struct cache *cache){
    struct set* setfree = cache->head_set;
    
    while(!setfree){
        struct line* line_free = setfree->line_head;
        while(!line_free){
            struct line * temp_line = line_free->next;
            free(line_free);
            line_free = temp_line;
        }
        struct set *temp_set = setfree->next;
        free(setfree);
        setfree = temp_set;
    }
    free(cache);
}



int main(int argc, char** argv){
    int opt;
    char op;
    unsigned addr;
    int size;


    while(-1 != (opt = getopt(argc, argv, "vhs:E:b:t:"))) {
        switch(opt) {
            case 'v':
                v_flag = 1;
                break;
            case 'h':
            	h_flag = 1;
            	break;
                
            case 's':
                s = atoi(optarg);
                if(s < 0 && s > m ){
                    printf("Error: s value must be in [0, word_length].\n");
                    exit(-1);
                }
                break;
                
            case 'E':
                E = atoi(optarg);
                if(E <= 0){
                    printf("Error: E value must be larger than 0.\n");
                    exit(-1);
                }
                break;
                
            case 'b':
                b = atoi(optarg);
                if(b < 0 || b > m){
                    printf("Error: b value must be in [0, word_length].\n");
                    exit(-1);
                }
                break;
                
            case 't':
                trace = optarg;
                break;
            default:
                break;
        }
    }

    t = m - s - b;
    
    struct cache *mycache = (struct cache *)malloc(sizeof(struct cache));
    init_cache(mycache, s, E);
    FILE *traceFile;
    traceFile = fopen(trace, "r");
    if (!traceFile){
        fprintf(stderr, "Error: Trace file cannot be opened.\n");
        return -1;
    }
    while(fscanf(traceFile, "%c %x, %d", &op, &addr, &size) > 0) {
        if(v_flag){
        	printf("%c %x, %d", op, addr, size);
        }
        switch(op){
        
            case 'L':
                cache_access(mycache, addr);
                break;
                
            case 'S':
                cache_access(mycache, addr);
                break;
                
            case 'M':
                cache_access(mycache, addr);
                cache_access(mycache, addr);
                break;
        }
        if (v_flag){
            printf("\n");
        }
    }
    fclose(traceFile);
    free_all(mycache);
    printSummary(hit, miss, evict);

    return 0;
}

/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
    int block;
    int row, col, i, j;
    int k, a0, a1, a2, a3, a4, a5, a6, a7;

       
    if (M == 32 && N == 32) {
        block = 8;
        for (row = 0; row < N; row += block){
            for (col = 0; col < M; col += block){
                for (i = row; i < row + block && i < N; ++i){
                    for (j = col; j < col + block && j < M; ++j){
                        if (i != j) {
                            a0 = A[i][j];
                            B[j][i] = a0;
                        }
                    }
                    if (row == col) {
                        a0 = A[i][i];
                        B[i][i] = a0;
                    }
                }
            }
        }
    }

       /*
        *  4X4 blocks
        *  if block is near diagnal, A[i][j] and B[j][i] cached in same set
        *  try to use every item before one is evicted by another
        */

    if (M == 64 && N == 64) {
        for(col=0; col<64; col+=8 ){
                for(row=0; row<64; row+=8 ){
                    for(k=0; k<4; k++){
                        a0 = A[col+k][row+0];
                        a1 = A[col+k][row+1];
                        a2 = A[col+k][row+2];
                        a3 = A[col+k][row+3];
                        a4 = A[col+k][row+4];
                        a5 = A[col+k][row+5];
                        a6 = A[col+k][row+6];
                        a7 = A[col+k][row+7];

                        // In the code, I comment "Good job" for the elements that are transposed correctly. "Later use" for later assignment
                        B[row+0][col+k+0] = a0;   // good job
                        B[row+0][col+k+4] = a5;    // later use
                        B[row+1][col+k+0] = a1;    // good job
                        B[row+1][col+k+4] = a6;    //later use
                        B[row+2][col+k+0] = a2;    // good job
                        B[row+2][col+k+4] = a7;    //later use
                        B[row+3][col+k+0] = a3;    // good job
                        B[row+3][col+k+4] = a4;    // later use
                    }


                    /* Part B, moving sub-matrix b to sub-matrix c
                     * and moving A->B for sub-matrix b and move matrix d
                     */
                    /*
                    Now that we have dealt with the first 4 col 8 arrow of A. The next job to deal with the "later use" assignment above. The "later use" assignments that we did above have taken a lot of places, so we need to bring these elements to their right positions.
                     */
                    a0 = A[col+4][row+4];
                    a1 = A[col+5][row+4];
                    a2 = A[col+6][row+4];
                    a3 = A[col+7][row+4];
                    a4 = A[col+4][row+3];
                    a5 = A[col+5][row+3];
                    a6 = A[col+6][row+3];
                    a7 = A[col+7][row+3];


                    B[row+4][col+0] = B[row+3][col+4];  // B[4][0] = a4 = A[0][4] For example
                    B[row+4][col+4] = a0;  // B[4][4] = A[4][4] For example
                    B[row+3][col+4] = a4;
                    B[row+4][col+1] = B[row+3][col+5];
                    B[row+4][col+5] = a1;
                    B[row+3][col+5] = a5;
                    B[row+4][col+2] = B[row+3][col+6];
                    B[row+4][col+6] = a2;
                    B[row+3][col+6] = a6;
                    B[row+4][col+3] = B[row+3][col+7];
                    B[row+4][col+7] = a3;
                    B[row+3][col+7] = a7;

                    // this loops deal with the the remaning elements .
                    for(k=0;k<3;k++){


                        a0 = A[col+4][row+5+k];
                        a1 = A[col+5][row+5+k];
                        a2 = A[col+6][row+5+k];
                        a3 = A[col+7][row+5+k];
                        a4 = A[col+4][row+k];
                        a5 = A[col+5][row+k];
                        a6 = A[col+6][row+k];
                        a7 = A[col+7][row+k];


                        B[row+5+k][col+0] = B[row+k][col+4];
                        B[row+5+k][col+4] = a0;
                        B[row+k][col+4] = a4;
                        B[row+5+k][col+1] = B[row+k][col+5];
                        B[row+5+k][col+5] = a1;
                        B[row+k][col+5] = a5;
                        B[row+5+k][col+2] = B[row+k][col+6];
                        B[row+5+k][col+6] = a2;
                        B[row+k][col+6] = a6;
                        B[row+5+k][col+3] = B[row+k][col+7];
                        B[row+5+k][col+7] = a3;
                        B[row+k][col+7] = a7;


                    }


                }
            }
    }

    if (M == 61 && N == 67) {
        block = 18;
        for (row = 0; row < N; row += block){
            for (col = 0; col < M; col += block){
                for (i = row; i < row + block && i < N; ++i){
                    for (j = col; j < col + block && j < M; ++j){
                        a0 = A[i][j];
                        B[j][i] = a0;
                    }
                }
            }
        }
    }
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

